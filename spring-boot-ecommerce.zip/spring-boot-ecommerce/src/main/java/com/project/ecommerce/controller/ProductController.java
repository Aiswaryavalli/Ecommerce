package com.project.ecommerce.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.ecommerce.entity.Product;
import com.project.ecommerce.entity.User;
import com.project.ecommerce.service.ProductService;

@RestController
@RequestMapping("/product")
@CrossOrigin(origins="http://localhost:4200/")
public class ProductController {
	@Autowired
	ProductService productService;
    @PostMapping("/post")
	public Product saveProduct(@RequestBody Product product) {
    	return productService.addProduct(product);
		
    	 }
    
   @PutMapping("/{id}")
    public Product updateProduct(@RequestBody Product product) {
	   return productService.updateProduct(product);
    	
    }
   
   @GetMapping("/allProduct")
   public List<Product> getAllProducts(){
//	List<Product> users = productService.getAllProducts();

	return productService.getAllProducts();
   }
   
   @GetMapping("/{productId}")
   public Product getProductById(@PathVariable Integer productId) {
	   
	   return productService.getProductById(productId);
	   
   }
   
   @GetMapping("/active")
   public List<Product> getActiveProducts(){
	   return productService.getAllActiveProducts();
   }
   
   @DeleteMapping("/{productId}")
   public void deleteProductById(@PathVariable Integer productId) {
	    productService.deleteProductById(productId);
   }
}
