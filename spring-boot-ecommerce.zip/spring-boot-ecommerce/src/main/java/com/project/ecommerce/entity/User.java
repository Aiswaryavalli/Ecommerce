package com.project.ecommerce.entity;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import org.hibernate.validator.constraints.NotBlank;
import lombok.Data;

@Entity
@Table(name= "USERS")
@Data
public class User {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="USER_ID")
	private Integer userId;
	
    @NotBlank(message = "Email cannot be blank")
   	@Column(name="USER_EMAIL")
	private String email;

    @NotBlank(message = "Username cannot be blank")
	@Column(name = "USER_NAME")
	private String userName;

    @NotBlank(message = "Password cannot be blank")
	@Column(name = "USER_PASSWORD")
	private String password;
    
//    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL)
//    private List<Cart> carts;

//	@OneToMany(mappedBy = "user",cascade = CascadeType.ALL)
//	private List<OrderDetails> orderDetails;

}
