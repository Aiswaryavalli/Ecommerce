package com.project.ecommerce.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.ecommerce.entity.OrderDetails;
import com.project.ecommerce.repository.OrderDetailsRepository;

import java.util.List;
import java.util.Optional;
@Service
public class OrderDetailsService {
   @Autowired
    OrderDetailsRepository orderDetailsRepository;
   public OrderDetails addOrderDetails(OrderDetails orderDetails) {
       return orderDetailsRepository.save(orderDetails);
   }
   public OrderDetails updateOrderDetails(OrderDetails orderDetails) {
       return orderDetailsRepository.save(orderDetails);
   }
   public List<OrderDetails> getAllOrders() {
       return orderDetailsRepository.findAll();
   }
   public OrderDetails getOrderDetailsById(Integer orderDeatilsId) {
       Optional<OrderDetails> orderdetails = orderDetailsRepository.findById(orderDeatilsId);
		return orderdetails.orElse(null);
   }
   public void deleteOrderDetailsById(Integer orderDetailsId) {
       orderDetailsRepository.deleteById(orderDetailsId);
   }
}