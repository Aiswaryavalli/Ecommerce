package com.project.ecommerce.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.ecommerce.entity.Category;
import com.project.ecommerce.service.CategoryService;

@RestController
@RequestMapping("/CATEGORIES")
@CrossOrigin("http://localhost:4200/")
public class CategoryController {

	@Autowired
	   private CategoryService categoryService;

	@PostMapping("/post")
	   public ResponseEntity<Category> createCategory(@RequestBody Category category)  { 
		try {
	          Category newCategory = categoryService.createCategory(category);
	           return ResponseEntity.ok(newCategory);
	       } catch (IllegalArgumentException e) {
	           return ResponseEntity.badRequest().body(null); // Return 400 Bad Request for invalid input
	       }
	   }
	

	   @GetMapping("/{categoryId}")
	   public ResponseEntity<Category> getCategoryById(@PathVariable Integer categoryId) {
	       try {
	           Category category = categoryService.getCategoryById(categoryId);
	           if (category != null) {
	               return ResponseEntity.ok(category);
	           } else {
	               return ResponseEntity.notFound().build(); // Return 404 Not Found if category not found
	           }
	       } catch (IllegalArgumentException e) {
	           return ResponseEntity.badRequest().body(null); // Return 400 Bad Request for invalid category ID
	       }
	   }

	   @GetMapping
	   public ResponseEntity<List<Category>> getAllCategories() {
	       List<Category> categories = categoryService.getAllCategories();
	       return ResponseEntity.ok(categories);
	   }
	   

	   @PutMapping("/{categoryId}")
	   public ResponseEntity<Category> updateCategory(@RequestBody Category category) {
	       try {
	           Category updatedCategory = categoryService.updateCategory(category);
	           return ResponseEntity.ok(updatedCategory);
	       } catch (IllegalArgumentException e) {
	           return ResponseEntity.badRequest().body(null); // Return 400 Bad Request for invalid input or non-existent category
	       }
	   }
	   
	   @DeleteMapping("/{categoryId}")
	   public ResponseEntity<Void> deleteCategory(@PathVariable Integer categoryId) {
	       try {
	           categoryService.deleteCategory(categoryId);
	           return ResponseEntity.noContent().build(); // Return 204 No Content on successful deletion
	       } catch (IllegalArgumentException e) {
	           return ResponseEntity.badRequest().build(); // Return 400 Bad Request for invalid input or non-existent category
	       }
	   }
}
