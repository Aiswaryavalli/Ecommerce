package com.project.ecommerce.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.ecommerce.entity.Order;
import com.project.ecommerce.repository.OrderRepository;

import java.util.List;
import java.util.Optional;
@Service
public class OrderService {
   @Autowired
    OrderRepository orderRepository;
   public Order addOrder(Order order) {
       return orderRepository.save(order);
   }
   public Order updateOrder(Order order) {
       return orderRepository.save(order);
   }
   public List<Order> getAllOrders() {
       return orderRepository.findAll();
   }
   public Order getOrderById(Integer orderId) {
       Optional<Order> order = orderRepository.findById(orderId);
       return order.orElse(null);
   }
   public void deleteOrderById(Integer orderId) {
       orderRepository.deleteById(orderId);
   }
}