package com.project.ecommerce.service;

import java.util.List;
import java.util.Optional;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.ecommerce.entity.Product;
import com.project.ecommerce.repository.ProductRepository;


@Service
public class ProductService {
	
	@Autowired
	ProductRepository productRepository;
	
	public Product addProduct(Product product) {
		if(productRepository.findByProductName(product.getProductName())!= null)
		{
			throw new IllegalArgumentException("A product with this name already exists.");
		}
		return productRepository.save(product);
	}
	
	public Product updateProduct(Product product) {
		return productRepository.save(product);
	}
	
	public List<Product> getAllProducts() {
		return productRepository.findAll();
		
	}
	
	public Product getProductById(Integer productId) {
		Optional<Product> optional = productRepository.findById(productId);
		return optional.orElse(null);
	}
    
	public void deleteProductById(Integer productId) {
		productRepository.deleteById(productId);
	}

	public List<Product> getAllActiveProducts() {
		return productRepository.findActiveProducts();
	}
}

