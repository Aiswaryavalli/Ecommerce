package com.project.ecommerce.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.ecommerce.entity.User;
import com.project.ecommerce.repository.UserRepository;


@Service
public class  UserService {

	@Autowired
	UserRepository userRepository;
      public User addUser(User user) {
		return userRepository.save(user);	
	}

	public User updateUser(User user) {
		return userRepository.save(user);
	}

	public List<User> getAllUsers() {
		return userRepository.findAll();
	}

	public User getUserById(Integer userId) {
		Optional<User> optional = userRepository.findById(userId);
		return optional.orElse(null);
	}

	public void deleteUserById(Integer userId) {
		userRepository.deleteById(userId);
	}
	
	public User getUserByEmail(String email) {
		return userRepository.findByEmail(email);
	}

	public User save(User user) {
		// TODO Auto-generated method stub
		return userRepository.save(user);
	}

}
