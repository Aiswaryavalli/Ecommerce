package com.project.ecommerce.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.project.ecommerce.entity.Cart;
import com.project.ecommerce.entity.User;

@Repository
public interface CartRepository extends JpaRepository<Cart, Integer> {

	@Query("SELECT c FROM Cart c  where c.user.userId=:userId")
	Optional<List<Cart>> findByUserId(int userId);

	@Query("SELECT c FROM Cart c  where c.product.productId=:productId")
	Cart findByProductId(Integer productId);

}