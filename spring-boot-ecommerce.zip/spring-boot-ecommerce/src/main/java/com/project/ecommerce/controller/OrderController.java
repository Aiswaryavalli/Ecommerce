package com.project.ecommerce.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.project.ecommerce.entity.Order;
import com.project.ecommerce.service.OrderService;

import java.util.List;
@RestController
@RequestMapping("/orders")
@CrossOrigin(origins="http://localhost:4200/")
public class OrderController {
   @Autowired
   OrderService orderService;
   @PostMapping
   public ResponseEntity<Order> createOrder(@RequestBody Order order) {
       Order createdOrder = orderService.addOrder(order);
       return new ResponseEntity<>(createdOrder, HttpStatus.CREATED);
   }
   @PutMapping("/{orderId}")
   public ResponseEntity<Order> updateOrder(@PathVariable Integer orderId, @RequestBody Order order) {
       order.setOrderId(orderId);
       Order updatedOrder = orderService.updateOrder(order);
       return new ResponseEntity<>(updatedOrder, HttpStatus.OK);
   }
   @GetMapping
   public ResponseEntity<List<Order>> getAllOrders() {
       List<Order> orders = orderService.getAllOrders();
       return new ResponseEntity<>(orders, HttpStatus.OK);
   }
   @GetMapping("/{orderId}")
   public ResponseEntity<Order> getOrderById(@PathVariable Integer orderId) {
       Order order = orderService.getOrderById(orderId);
       if (order != null) {
           return new ResponseEntity<>(order, HttpStatus.OK);
       } else {
           return new ResponseEntity<>(HttpStatus.NOT_FOUND);
       }
   }
   @DeleteMapping("/{orderId}")
   public ResponseEntity<Void> deleteOrderById(@PathVariable Integer orderId) {
       orderService.deleteOrderById(orderId);
       return new ResponseEntity<>(HttpStatus.NO_CONTENT);
   }
}