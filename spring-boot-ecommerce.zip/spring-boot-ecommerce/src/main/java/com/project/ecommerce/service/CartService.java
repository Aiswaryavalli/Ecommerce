package com.project.ecommerce.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.ecommerce.entity.Cart;
import com.project.ecommerce.entity.Product;
import com.project.ecommerce.entity.User;
import com.project.ecommerce.repository.CartRepository;
import com.project.ecommerce.repository.ProductRepository;
import com.project.ecommerce.repository.UserRepository;

@Service
public class CartService {

    @Autowired
    private CartRepository cartRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ProductRepository productRepository;

    public void addProductToCart(Cart cart) {
    	System.out.println(cart);
        User user = userRepository.findById(cart.getUser().getUserId())
                .orElseThrow(() -> new RuntimeException("User not found"));
        Product product = productRepository.findById(cart.getProduct().getProductId())
                .orElseThrow(() -> new RuntimeException("Product not found"));
        Cart item=cartRepository.findByProductId(cart.getProduct().getProductId());
        if(item==null) {
        cart.setUser(user);
        cart.setProduct(product);
        cart.setTotal((cart.getPrice() * cart.getQuantity()) - cart.getDiscount());

        cartRepository.save(cart);}
        else {
        	int quantity=item.getQuantity()+cart.getQuantity();
        	item.setQuantity(quantity);
        	item.setTotal((item.getPrice() * item.getQuantity()) - cart.getDiscount());
        	this.cartRepository.save(item);
        }
    }

    public void updateCart(int cartId, Cart cart) {
        Cart existingCart = cartRepository.findById(cartId)
                .orElseThrow(() -> new RuntimeException("Cart item not found"));
        
        existingCart.setQuantity(cart.getQuantity());
        existingCart.setPrice(cart.getPrice());
        existingCart.setDiscount(cart.getDiscount());
        double total = (cart.getPrice() * cart.getQuantity()) - cart.getDiscount();
        existingCart.setTotal(total);
        
        cartRepository.save(existingCart);
    }

    public Cart getCartById(int cartId) {
        return cartRepository.findById(cartId)
                .orElseThrow(() -> new RuntimeException("Cart item not found"));
    }

    public void deleteCart(int cartId) {
        if (!cartRepository.existsById(cartId)) {
            throw new RuntimeException("Cart item not found");
        }
        cartRepository.deleteById(cartId);
    }

	public List<Cart> getCartByUserId(int userId) {
	
		return cartRepository.findByUserId(userId)
                .orElseThrow(() -> new RuntimeException("Cart item not found"));	}
}
