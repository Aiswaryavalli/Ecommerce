package com.project.ecommerce.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.ecommerce.entity.User;
import com.project.ecommerce.service.UserService;

import jakarta.validation.Valid;

@RestController

@RequestMapping("/USERS")
@Validated

@CrossOrigin("http://localhost:4200/")
public class UserController {

	@Autowired
	UserService userService;

	@PostMapping("/login")
	public ResponseEntity<?> login(@RequestBody User user) {
		if (user == null || user.getEmail() == null || user.getEmail().isEmpty()) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Email is required");
		}
		String email = user.getEmail();
		String password = user.getPassword();
		User user1 = userService.getUserByEmail(email);
		if (user1 != null) {
			if (user1.getPassword().equals(password)) {
				return ResponseEntity.ok(user1);
			} else {
				return ResponseEntity.status(HttpStatus.OK).body("Incorrect password");
			}
		} else {
			return ResponseEntity.status(HttpStatus.OK).body("User not found");
		}
	}

	@PostMapping("/newregister" )
	public ResponseEntity<?> addUser(@RequestBody @Valid User user) {
		User existingUser = userService.getUserByEmail(user.getEmail());
		if (existingUser != null) {
			return ResponseEntity.status(HttpStatus.CONFLICT).body("User already exists with this email.");
		}

		// Check password validity (e.g., length, complexity)
		if (!isPasswordValid(user.getPassword())) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Password does not meet the criteria.");
		}

		User savedUser = userService.save(user);
		return ResponseEntity.status(HttpStatus.CREATED).body(savedUser);
	}

	private boolean isPasswordValid(String password) {
		// Example validation: Password must be at least 8 characters long
		return password != null && password.length() >= 8;
	}

	@PutMapping("/{id}")
	public ResponseEntity<User> updateUser(@PathVariable Integer id, @Valid @RequestBody User user) {
		user.setUserId(id);
		User updatedUser = userService.updateUser(user);
		return ResponseEntity.ok(updatedUser);
	}

	@GetMapping
	public ResponseEntity<List<User>> getAllUsers() {
		List<User> users = userService.getAllUsers();
		return ResponseEntity.ok(users);
	}

	@GetMapping("/{id}")
	public ResponseEntity<User> getUserById(@PathVariable Integer id) {
		User user = userService.getUserById(id);
		if (user != null) {
			return ResponseEntity.ok(user);
		} else {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
		}
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deleteUserById(@PathVariable Integer id) {
		userService.deleteUserById(id);
		return ResponseEntity.noContent().build();
	}

}
