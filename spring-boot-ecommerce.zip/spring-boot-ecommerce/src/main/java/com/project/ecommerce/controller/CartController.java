package com.project.ecommerce.controller;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.project.ecommerce.entity.Cart;
import com.project.ecommerce.service.CartService;

@RestController
@RequestMapping("/cart")
@CrossOrigin(origins="http://localhost:4200/")

public class CartController {

    @Autowired
    private CartService cartService;

    @PostMapping("/add" )
    public ResponseEntity<String> addProductToCart(@RequestBody Cart cart) {
        try {
        	
            cartService.addProductToCart(cart);
            return  ResponseEntity.ok("Product added to cart successfully!");
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

  
    
    @PutMapping("/update/{cartId}")
    public ResponseEntity<String> updateCart(@PathVariable int cartId, @RequestBody Cart cart) {
        try {
            cartService.updateCart(cartId, cart);
            return new ResponseEntity<>("Cart updated successfully!", HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/{cartId}")
    public ResponseEntity<Cart> getCartById(@PathVariable int cartId) {
        try {
            Cart cart = cartService.getCartById(cartId);
            return new ResponseEntity<>(cart, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<List<Cart>> getCartByUserId(@PathVariable int userId) {
        try {
            List<Cart> cart = cartService.getCartByUserId(userId);
            return new ResponseEntity<>(cart, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
        }
    }
    
    @DeleteMapping("/delete/{cartId}")
    public ResponseEntity<String> deleteCart(@PathVariable int cartId) {
        try {
        	System.out.println(cartId);
            cartService.deleteCart(cartId);
            return new ResponseEntity<>("Cart item deleted successfully!", HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
        }
    }
}
