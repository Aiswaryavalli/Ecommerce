package com.project.ecommerce.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name = "Details")
@Data
public class OrderDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ORDERDETAILS_ID")
	private Integer orderDetailsId;

	@ManyToOne
	@JoinColumn(name = "ORDER_ID", nullable = false)
	private Order order;

	@ManyToOne
	@JoinColumn(name = "CART_ID", nullable = false)
	private Cart cart;

	@Column(name = "QUANTITY", nullable = 	false)
	private Integer quantity;

	@Column(name = "PRICE", nullable = false)
	private Double price;

	@Column(name = "DISCOUNT", nullable = false)
	private Double discount;

	@Column(name = "TOTAL", nullable = false)
	private Double total;

	@ManyToOne
	@JoinColumn(name = "USER_ID", nullable = false)
	private User user;

	@ManyToOne
	@JoinColumn(name = "PRODUCT_ID", nullable = false)
	private Product product;

}