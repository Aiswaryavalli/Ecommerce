package com.project.ecommerce.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.project.ecommerce.entity.OrderDetails;
import com.project.ecommerce.service.OrderDetailsService;

import java.util.List;
@RestController
@RequestMapping("/details")
@CrossOrigin(origins="http://localhost:4200/")
public class OrderDetailsController {
   @Autowired
   OrderDetailsService orderDetailsService;
   @PostMapping
   public ResponseEntity<OrderDetails> createOrderDetails(@RequestBody OrderDetails orderDetails) {
       OrderDetails createdOrderDetails = orderDetailsService.addOrderDetails(orderDetails);
       return new ResponseEntity<>(createdOrderDetails, HttpStatus.CREATED);
   }
   @PutMapping("/{orderDetailsId}")
   public ResponseEntity<OrderDetails> updateOrderDetails(@PathVariable Integer orderDetailsId, @RequestBody OrderDetails orderDetails) {
       orderDetails.setOrderDetailsId(orderDetailsId);
       OrderDetails updatedOrderDetails = orderDetailsService.updateOrderDetails(orderDetails);
       return new ResponseEntity<>(updatedOrderDetails, HttpStatus.OK);
   }
   @GetMapping
   public ResponseEntity<List<OrderDetails>> getAllOrders() {
       List<OrderDetails> orderDetails = orderDetailsService.getAllOrders();
       return new ResponseEntity<>(orderDetails, HttpStatus.OK);
   }
   @GetMapping("/{orderDetailsId}")
   public ResponseEntity<OrderDetails> getOrderDetailsById(@PathVariable Integer orderDetailsId) {
       OrderDetails orderDetails = orderDetailsService.getOrderDetailsById(orderDetailsId);
       if (orderDetails != null) {
           return new ResponseEntity<>(orderDetails, HttpStatus.OK);
       } else {
           return new ResponseEntity<>(HttpStatus.NOT_FOUND);
       }
   }
   @DeleteMapping("/{orderDetailsId}")
   public ResponseEntity<Void> deleteOrderDetailsById(@PathVariable Integer orderDetailsId) {
       orderDetailsService.deleteOrderDetailsById(orderDetailsId);
       return new ResponseEntity<>(HttpStatus.NO_CONTENT);
   }
}