package com.project.ecommerce.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.ecommerce.entity.Category;
import com.project.ecommerce.repository.CategoryRepository;


@Service
public class CategoryService {
	
	 @Autowired
	   private CategoryRepository categoryRepository;
	   public Category createCategory(Category category) {
		   if(categoryRepository.findByCategoryName(category.getCategoryName()) != null){
			   throw new IllegalArgumentException("Category already exists");
		   }
	       return categoryRepository.save(category);
	   }
	   public Category getCategoryById(Integer categoryId) {
	       if (categoryId == null || categoryId <= 0) {
	           throw new IllegalArgumentException("Category ID must be greater than zero.");
	       }
	       else {
           Optional<Category> optionalCategory = categoryRepository.findById(categoryId);
	       return optionalCategory.orElse(null);
	       }
	   }
	   public List<Category> getAllCategories() {
	       return categoryRepository.findAll();
	   }
	   public Category updateCategory(Category category) {
	       Integer categoryId = category.getCategoryId();
	       if (categoryId == null || categoryId <= 0 || !categoryRepository.existsById(categoryId)) {
	           throw new IllegalArgumentException("Category with ID " + categoryId + " does not exist.");
	       }
	       return categoryRepository.save(category);
	   }
	   public void deleteCategory(Integer categoryId) {
	       if (categoryId == null || categoryId <= 0 || !categoryRepository.existsById(categoryId)) {
	           throw new IllegalArgumentException("Category with ID " + categoryId + " does not exist.");
	       }
	       categoryRepository.deleteById(categoryId);
	   }
}
	 
	 
	
